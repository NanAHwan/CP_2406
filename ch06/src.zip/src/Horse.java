public class Horse
{
    private String name;
    private String color;
    private int birthYear;
    public String getName()
    {
        return name;
    }
    public String getColor()
    {
        return color;
    }
    public int getBirthYear()
    {
        return birthYear;
    }
    public void setName(String n)
    {
        name = n;
    }
    public void setColor(String c)
    {
        color = c;
    }
    public void setBirthYear(int y)
    {
        birthYear = y;
    }
}