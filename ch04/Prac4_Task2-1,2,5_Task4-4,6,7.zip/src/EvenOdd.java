import java.util.Scanner;
public class EvenOdd
{
    public static void main(String args[])
    {
        Scanner askUser = new Scanner(System.in);
        System.out.println("Please enter a number: ");
        int num = askUser.nextInt();
        if(num % 2 == 0)
        {
            System.out.println(num + " is even.");
        }
        else
            System.out.println(num+" is odd.");
    }

}
